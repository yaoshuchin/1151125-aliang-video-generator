---
name: video-generator-ai-bridge
description: 幫學員把「線上的影片製作包生成器」接上自己電腦裡的 Claude Code／Codex／Antigravity。學員說「幫我串接生成器」「照 SKILL.md 串接」「生成器的 AI 沒亮燈」時使用。
---

# AI 串接包：讓線上生成器叫得動你電腦裡的 AI

線上生成器：https://video-generator-aliang.netlify.app
這個資料夾只有一支「AI 串接器」（AI串接器.py）。它只做一件事：把線上生成器送來的提示詞交給你電腦裡已登入的 AI 終端機，再把回答傳回網頁。
它只綁 127.0.0.1（別台電腦連不進來），也只接受生成器網址的請求，其他網站叫不動。

## 給 AI 的步驟（照順序做，每一步做完用白話回報給使用者）

1. **檢查 Python**：執行 `python --version`。沒有的話請使用者先完成課程 U01 的安裝，不要自己下載安裝程式。
2. **檢查 AI 終端機**：分別執行 `claude --version`、`codex --version`、`agy --version`，列出哪幾個有裝。至少要有一個。
3. **啟動串接器**：在這個資料夾，用「新開一個視窗、背景常駐」的方式執行，不要卡住你自己的對話：
   - Windows：`start "AI 串接器" cmd /k python AI串接器.py`
   - 若 `python` 不行，改用 `py`。
4. **確認有在跑**：執行
   `python -c "import urllib.request;print(urllib.request.urlopen('http://127.0.0.1:8899/engines').read().decode())"`
   看到 `"bridge"` 和各引擎 `"ok": true` 就代表成功。
5. **告訴使用者接下來怎麼做**（照抄這段給他）：
   - 用 Chrome 打開 https://video-generator-aliang.netlify.app
   - 第一步「先選你喜歡的做法」下面，按「🔄 重新偵測」。
   - Chrome 若跳出「要允許這個網站存取本機網路上的裝置嗎？」，按「允許」。
   - 看到 AI 引擎亮綠燈、右上角寫「已串接｜AI 引擎：…」就接好了。
   - 黑色的「AI 串接器」視窗用生成器的時候不要關；關掉＝停止串接。

## 下次再用
雙擊「開啟AI串接器.cmd」就好（或再請 AI 照這份 SKILL.md 做一次）。

## 常見問題
- **按了重新偵測還是沒亮燈**：確認黑色視窗還開著，而且寫「AI 串接器 已啟動」；Chrome 的網址列左邊按鎖頭 →「網站設定」→「本機網路存取」改成「允許」，重新整理。
- **黑色視窗寫「已經在執行」**：表示之前開過了，直接回生成器按重新偵測。
- **生成失敗：Please run /login**：那個 AI 的登入過期，在終端機打 `claude` 後輸入 `/login`（Codex 打 `codex login`）重新登入。
- **API Error: 403 Cloudflare**：網路擋住了 Claude，關掉 VPN 或改用手機熱點，或在生成器改選 Codex／Antigravity。
- **安全**：串接器不讀寫你的檔案，AI 在暫存資料夾回答完就刪除；不用貼任何密碼或金鑰。

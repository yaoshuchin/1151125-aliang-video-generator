@echo off
chcp 65001 >nul
title AI 串接器（開著＝串接中）
cd /d "%~dp0"
python "AI串接器.py"
if errorlevel 1 py "AI串接器.py"
pause

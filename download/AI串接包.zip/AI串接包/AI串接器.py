"""AI 串接器｜讓「線上的影片生成器網頁」叫得動你電腦裡的 Claude Code／Codex／Antigravity

- 只做一件事：收到線上生成器送來的「提示詞」，交給你電腦裡已登入的 AI 終端機，把回答傳回去。
- 只綁 127.0.0.1（外面的電腦連不進來），而且只接受課程生成器網址送來的請求，其他網站叫不動。
- 不讀寫你的檔案：AI 在一個暫存資料夾裡回答，回答完就刪掉。
- 只用 Python 內建功能。啟動：雙擊「開啟AI串接器.cmd」（視窗開著＝串接中，關掉＝停止）。
"""
import json, os, re, shutil, socket, subprocess, sys, tempfile, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

PORT = int(os.environ.get("VG_BRIDGE_PORT", 8899))
ALLOW = re.compile(r"^(https://(video-generator-aliang\.netlify\.app|[0-9a-f]{24}--video-generator-aliang\.netlify\.app)|http://(127\.0\.0\.1|localhost):\d+)$")
VERSION = "2026.11.13"
ENGINES = [
    {"id": "claude", "name": "Claude Code", "cmd": "claude"},
    {"id": "codex", "name": "Codex", "cmd": "codex"},
    {"id": "agy", "name": "Antigravity", "cmd": "agy"},
]
_ENGINE_CACHE = {"t": 0, "v": None}


def _port_busy(port):
    """Windows 上兩個程式可以綁同一個埠，所以啟動前先試連：連得上＝已經有一台在跑。"""
    s = socket.socket(); s.settimeout(0.5)
    try:
        return s.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s.close()


def which(cmd):
    return shutil.which(cmd) or shutil.which(cmd + ".cmd") or shutil.which(cmd + ".exe")


def detect():
    if _ENGINE_CACHE["v"] and time.time() - _ENGINE_CACHE["t"] < 60:
        return _ENGINE_CACHE["v"]
    out = []
    for e in ENGINES:
        p = which(e["cmd"])
        ver = ""
        if p:
            try:
                ver = subprocess.run([p, "--version"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20).stdout.strip().splitlines()[0][:40]
            except Exception:
                ver = ""
        out.append({"id": e["id"], "name": e["name"], "ok": bool(p), "version": ver})
    _ENGINE_CACHE.update(t=time.time(), v=out)
    return out


def extract_json(text):
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except Exception:
        pass
    i, j = text.find("{"), text.rfind("}")
    if i >= 0 and j > i:
        return json.loads(text[i:j + 1])
    raise ValueError("AI 沒有回傳 JSON：" + text[:200])


def explain(msg):
    """把 AI 終端機的錯誤翻成白話，前面放原因、後面附原文（2026-11-13：原本只取最後 400 字，原因被切掉）"""
    m = str(msg or "").strip()
    low = m.lower()
    tips = [("/login", "這個 AI 的登入過期了：在終端機打 claude 再輸入 /login（Codex 打 codex login）重新登入"),
            ("not logged in", "這個 AI 還沒登入：在終端機打 claude 再輸入 /login（Codex 打 codex login）"),
            ("cloudflare", "網路擋住了這個 AI（403 Cloudflare）：關掉 VPN 或改用手機熱點，或在生成器改選別的 AI"),
            ("403", "連線被拒絕（403）：關掉 VPN 或改用手機熱點，或在生成器改選別的 AI"),
            ("usage limit", "這個 AI 的用量額度用完了：先在生成器改選別的 AI"),
            ("rate limit", "這個 AI 呼叫太頻繁或額度用完：等一下再試，或改選別的 AI"),
            ("credit", "這個 AI 的額度不足：先在生成器改選別的 AI"),
            ("model", "指定的模型不能用：在生成器改選別的 AI，或更新這個 AI 終端機")]
    for k, t in tips:
        if k in low:
            return t + "。原文：" + m[:300]
    return "AI 回報失敗：" + m[:400]


def run_engine(engine, prompt, schema, timeout=300):
    p = which({"claude": "claude", "codex": "codex", "agy": "agy"}[engine])
    if not p:
        raise RuntimeError("這台電腦沒有安裝 " + engine)
    work = tempfile.mkdtemp(prefix="vg_ai_")
    sch = os.path.join(work, "schema.json")
    json.dump(schema, open(sch, "w", encoding="utf-8"), ensure_ascii=False)
    env = dict(os.environ)
    try:
        if engine == "claude":
            r = subprocess.run([p, "-p", "--output-format", "json"], cwd=work, capture_output=True, text=True, input=prompt,
                               encoding="utf-8", errors="replace", timeout=timeout, env=env)
            try:
                j = json.loads(r.stdout or "{}")
            except Exception:
                j = {}
            if r.returncode != 0 or j.get("is_error"):
                raise RuntimeError(explain(j.get("result") or j.get("subtype") or r.stderr or r.stdout))
            return extract_json(j.get("result", ""))
        if engine == "codex":
            outp = os.path.join(work, "out.txt")
            r = subprocess.run([p, "exec", "--skip-git-repo-check", "--ephemeral", "-s", "read-only", "--output-schema", sch, "-o", outp, "-"],
                               cwd=work, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, env=env, input=prompt)
            if r.returncode != 0 or not os.path.exists(outp):
                raise RuntimeError(explain(r.stderr or r.stdout))
            return extract_json(open(outp, encoding="utf-8").read())
        if engine == "agy":
            pf = os.path.join(work, "prompt.txt"); open(pf, "w", encoding="utf-8").write(prompt)
            r = subprocess.run([p, "-p", "請讀取並完全照做這個檔案裡的指示：" + pf, "--json-schema", sch, "--output-format", "json", "--add-dir", work],
                               cwd=work, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, env=env, stdin=subprocess.DEVNULL)
            if r.returncode != 0:
                raise RuntimeError(explain(r.stderr or r.stdout))
            j = json.loads(r.stdout)
            return j.get("structured_output") or extract_json(j.get("response", ""))
    finally:
        shutil.rmtree(work, ignore_errors=True)


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _origin_ok(self):
        o = self.headers.get("Origin", "")
        return bool(ALLOW.match(o)), o

    def _cors(self, o):
        self.send_header("Access-Control-Allow-Origin", o)
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")

    def _json(self, obj, code=200, o=""):
        d = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        if o: self._cors(o)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(d)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers(); self.wfile.write(d)

    def do_OPTIONS(self):
        ok, o = self._origin_ok()
        self.send_response(204 if ok else 403)
        if ok: self._cors(o)
        self.end_headers()

    def do_GET(self):
        ok, o = self._origin_ok()
        if self.path.startswith("/engines"):
            if not ok and self.headers.get("Origin"):
                return self._json({"error": "這個網站不能使用串接器"}, 403)
            return self._json({"bridge": VERSION, "engines": detect()}, o=o if ok else "")
        self._json({"bridge": VERSION, "hint": "AI 串接器運作中。請回到線上生成器網頁按「🔄 重新偵測」。"}, o=o if ok else "")

    def do_POST(self):
        ok, o = self._origin_ok()
        if not ok:
            return self._json({"error": "這個網站不能使用串接器"}, 403)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._json({"error": "資料格式不對"}, 400, o)
        if self.path.startswith("/run"):
            eng, prompt, schema = body.get("engine"), body.get("prompt"), body.get("schema")
            if eng not in ("claude", "codex", "agy") or not isinstance(prompt, str) or not isinstance(schema, dict) or len(prompt) > 60000:
                return self._json({"error": "請求內容不對"}, 400, o)
            t0 = time.time()
            print(time.strftime("%H:%M:%S"), f"收到生成請求 → {eng}", flush=True)
            try:
                raw = run_engine(eng, prompt, schema)
                print(time.strftime("%H:%M:%S"), f"完成（{round(time.time() - t0)} 秒）", flush=True)
                return self._json({"raw": raw, "seconds": round(time.time() - t0, 1)}, o=o)
            except Exception as e:
                print(time.strftime("%H:%M:%S"), "失敗：", str(e)[:200], flush=True)
                return self._json({"error": str(e)[:500]}, o=o)
        self._json({"error": "not found"}, 404, o)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if _port_busy(PORT):
        print(f"AI 串接器已經在執行（127.0.0.1:{PORT}），不用再開一次。"); sys.exit(0)
    print("=" * 56)
    print(" AI 串接器 已啟動（這個視窗開著＝串接中，關掉＝停止）")
    print(f" 位址：http://127.0.0.1:{PORT}")
    for e in detect():
        print(f"  {'[可用]' if e['ok'] else '[沒裝]'} {e['name']}  {e['version'] or ('已安裝' if e['ok'] else '沒偵測到')}")
    print(" 下一步：打開線上生成器 https://video-generator-aliang.netlify.app")
    print("        第一步按「🔄 重新偵測」，看到綠燈就接好了。")
    print(" Chrome 若跳出「允許存取本機網路裝置」，請按「允許」。")
    print("=" * 56, flush=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
